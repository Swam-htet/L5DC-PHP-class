<?php
function Here($here)
{
    echo "<h4 class='bg-warning p-2 text-center'>You are here -  " . $here . "</h4>";
}
