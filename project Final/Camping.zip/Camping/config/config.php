<?php

// config
$host = "localhost:3300";
$username = "root";
$password = "";
$dbName = "CampDB";
